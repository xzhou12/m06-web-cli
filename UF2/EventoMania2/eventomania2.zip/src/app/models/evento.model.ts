export interface Evento {
  titulo: string;
  artista: string;
  direccion: string;
  fecha: Date;
  precio: number;
}
