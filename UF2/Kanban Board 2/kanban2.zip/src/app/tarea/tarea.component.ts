import {Component, Input, OnInit, EventEmitter, Output} from '@angular/core';
import {Tarea} from "../models/tarea-model";

@Component({
  selector: 'app-tarea',
  templateUrl: './tarea.component.html',
  styleUrls: ['./tarea.component.css']
})
export class TareaComponent implements OnInit {

  @Input() tarea: Tarea;
  @Output() editar = new EventEmitter<Tarea>();

  hoy: Date = new Date();

  constructor() {
    this.tarea = {
      id: 0,
      lista: "",
      img: "",
      titulo: "",
      usuarios: [{img: '', alt: '', nick: '', email: ''}],
      fechaFin: new Date
    }
  }

  ngOnInit(): void {
  }

  comprobarFecha(fecha: Date | string, lista: string) {
    const fechaObj = fecha instanceof Date ? fecha : new Date(fecha);
    const hoy = new Date();
    const unDiaEnMilisegundos = 24 * 60 * 60 * 1000; // 1 día en milisegundos

    const diferenciaEnTiempo = fechaObj.getTime() - hoy.getTime();

    if (diferenciaEnTiempo < 0 && !this.estaEnListaFinalizadas(lista)) {
      return 'rojo'; // Ha pasado y no está en la lista de Finalizadas
    } else if (diferenciaEnTiempo < 0 && this.estaEnListaFinalizadas(lista)) {
      return 'verde'; // Ha pasado y está en la lista de Finalizadas
    } else if (diferenciaEnTiempo <= unDiaEnMilisegundos) {
      return 'naranja'; // Falta 1 día o menos para vencer
    } else {
      return 'gris'; // En el resto de los casos
    }
  }


  estaEnListaFinalizadas(lista: string): boolean {
    if (lista == 'Finalizadas') {
      return true;
    } else {
      return false;
    }
  }

  editarTarea() {
    this.editar.emit(this.tarea);
  }

}
