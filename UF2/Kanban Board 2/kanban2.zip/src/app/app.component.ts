import {Component} from '@angular/core';
import {Tarea} from './models/tarea-model';

const k_PENDIENTES_LISTA: string = "Pendientes";
const k_PROGRESO_LISTA: string = "Progreso";
const k_FINALIZADAS_LISTA: string = "Finalizadas";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  listas: string[] = [];
  tareas: Tarea[];
  tarea: Tarea | undefined;
  editando = false;
  tareaExistente: boolean = false;

  constructor() {

    const tareasJSON: string = `{
    "tareas": [
        { "id": 0, "lista": "${k_FINALIZADAS_LISTA}", "img":"https://picsum.photos/300/200", "titulo": "Tarea 1: Diseño UI","usuarios": [{"email": "lponts@ilerna.com", "img":"https://picsum.photos/300/300", "nick": "Juan", "alt":"Usuario"}], "fechaFin": "2019-01-16" },
        { "id": 1, "lista": "${k_PROGRESO_LISTA}", "img":"https://picsum.photos/300/200", "titulo": "Tarea 2: Diseño de todo el Backend", "usuarios": [], "fechaFin": "2022-11-09" },
        { "id": 2, "lista": "${k_PENDIENTES_LISTA}", "img": null,"titulo": "Tarea 3: Diseño de la base de datos", "usuarios":[{"email": "jdominguez@ilerna.com", "img":"https://picsum.photos/200/200", "nick": "Jose", "alt": "Usuario"},{ "email": "lponts@ilerna.com", "img":"https://picsum.photos/100/100", "nick": "Laura", "alt":"Usuario"}], "fechaFin": "2022-11-16" },
        { "id": 3, "lista": "${k_PENDIENTES_LISTA}", "img": null, "titulo": "Tarea 4: Implementar todo el Front-End", "usuarios": [],"fechaFin": null }
      ]
    }`;

    const tareasDict: any = JSON.parse(tareasJSON);
    this.tareas = tareasDict['tareas'];

    this.listas.push(k_PENDIENTES_LISTA);
    this.listas.push(k_PROGRESO_LISTA);
    this.listas.push(k_FINALIZADAS_LISTA);
  }

  /*
  Retorna las tareas pendientes
   */
  obtenerPendientes() {
    return this.tareas.filter(value => value.lista == 'Pendientes');
  }

  /*
  Retorna las tareas en progreso
   */
  obtenerEnProgreso() {
    return this.tareas.filter(value => value.lista == 'Progreso');
  }

  /*
  Retorna las tareas finalizadas
   */
  obtenerFinalizadas() {
    return this.tareas.filter(value => value.lista == 'Finalizadas');
  }

  /*
  Añade nuevas tareas en la array de tareas
   */
  addFormulario(event: Tarea): void {

    // Si la tarea ya existia
    if (this.tareaExistente) {

      // Busca la tarea que desea modificar
      const tareaActualizada = this.tareas.find(t => t.id === event.id);

      if (tareaActualizada) {
        // Actualiza la tarea con los datos del evento
        tareaActualizada.lista = event.lista;
        tareaActualizada.img = event.img;
        tareaActualizada.titulo = event.titulo;
        tareaActualizada.usuarios = event.usuarios;
        tareaActualizada.fechaFin = event.fechaFin;

      }

    } else {

      // Si es una nueva tarea, añade un id
      let newId = this.tareas.length;

      // Y crea la nueva tarea
      this.tareas.push({...event, id: newId});
    }


    this.tareaExistente = false;

  }

  // Editar tarea
  editarTarea(event: Tarea): void {
    this.tarea = event;
    this.tareaExistente = true;
    this.editando = !this.editando;
  }

  // Cancela el formulario
  cancelarFormulario() {
    // Modifica a false la tareaExistente y cambia el valor a editando
    this.tareaExistente = false;
    this.editando = !this.editando;
  }


}
