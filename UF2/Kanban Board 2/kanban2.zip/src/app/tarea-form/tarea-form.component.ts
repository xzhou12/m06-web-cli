import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Tarea} from "../models/tarea-model";
import {Usuario} from "../models/usuario-model";

@Component({
  selector: 'app-tarea-form',
  templateUrl: './tarea-form.component.html',
  styleUrls: ['./tarea-form.component.css']
})

export class TareaFormComponent implements OnInit {

  tascaForm!: FormGroup;
  tarea: Tarea | undefined;

  @Input() editarTarea?: Tarea;
  @Input() tareaExistente: boolean = false;

  @Output() formularioEnviado = new EventEmitter<Tarea>();
  @Output() cancelarFormulario = new EventEmitter<void>();

  constructor(private fb: FormBuilder) {
    this.tascaForm = this.fb.group({
      titulo: ['', Validators.required],
      lista: ['', Validators.required],
      fechaFin: [null],
      img: [''],
      usuarios: this.fb.array([]),
    });
  }

  ngOnInit() {

    // Comprueba si se esta editando una tarea existente
    if (this.tareaExistente) {

      // Rellena los datos en el formulario
      this.tascaForm = this.fb.group({
        titulo: [this.editarTarea?.titulo, Validators.required],
        lista: [this.editarTarea?.lista, Validators.required],
        fechaFin: [this.editarTarea?.fechaFin],
        img: [this.editarTarea?.img],
        usuarios: this.fb.array([]),
      });

      // Coge los usuarios de la array
      const usuariosArray = this.tascaForm.get('usuarios') as FormArray;

      // Rellena los datos de los usuarios en el formualrio
      this.editarTarea!.usuarios.forEach(usuario => {
        usuariosArray.push(this.fb.group({
          email: [usuario.email],
          img: [usuario.img],
          nick: [usuario.nick],
          alt: [usuario.alt]
        }));
      });
    }
  }

  /*
  Guardar datos y enviarlos
  */
  guardar(): void {

    // Si la tarea existe, es decir, se tiene que editar una tarea
    if (this.tareaExistente) {
      // Añade el id de la tarea al array
      let newId = this.editarTarea?.id;
      const tascaFormId = {...this.tascaForm.value, id: newId};

      // Y envia los datos
      this.formularioEnviado.emit(tascaFormId);

    } else {
      this.formularioEnviado.emit(this.tascaForm.value);

    }

    // Vuelve a la pagina principal
    this.cancelarVolver();
  }


  /*
  Añade usuarios a la tarea
  */
  addUsers() {
    const newUser: Usuario = {
      "email": "lponts@ilerna.com",
      "img": "https://picsum.photos/100/100",
      "nick": "Juan",
      "alt": "Usuario"
    };

    // Añade los usuarios a la array del formulario
    const usuariosFormArray = this.tascaForm.get('usuarios') as FormArray;
    usuariosFormArray.push(this.fb.group({...newUser}));

  }

  /*
  Elimina los usuarios de la tarea
  */
  deleteUsers() {
    // Selecciona el objeto usuarios como array
    const usuariosFormArray = this.tascaForm.get('usuarios') as FormArray;
    // Elimina la ultima posicion
    usuariosFormArray.removeAt(usuariosFormArray.length - 1);
  }


  /*
  Devuelve la cantidad de usuarios que hay en la tarea
  */
  cantidadUsuarios(): number {
    const usuariosFormArray = this.tascaForm.get('usuarios') as FormArray;
    return usuariosFormArray.length;

  }


  /*
  Obtiene las imagenes para mostrarlos en la tarea
  */
  obtenerImagenes(): string[] {

    // Selecciona el objeto usuarios como array
    const userFormArray = this.tascaForm.get('usuarios') as FormArray;

    if (userFormArray) {

      // Retorna una una String[] con las img de todos los usuarios
      return userFormArray.controls.map((usuario) => {
        const imgControl = usuario.get('img');
        return imgControl ? imgControl.value : null;
      });
    }

    return [];
  }

  // Cancela todo y vuelve
  cancelarVolver() {
    this.cancelarFormulario.emit();
  }

}

