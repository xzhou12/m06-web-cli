export interface Tarjeta {
  avatar: string;
  nombre: string;
  apodo: string;
  imagen: string;
  descripcion: string;
  favorito: boolean;
  gusta: boolean;
}
