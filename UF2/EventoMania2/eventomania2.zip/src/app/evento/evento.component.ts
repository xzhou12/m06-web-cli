import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Evento} from "../models/evento.model";

@Component({
  selector: 'app-evento',
  templateUrl: './evento.component.html',
  styleUrls: ['./evento.component.css']
})
export class EventoComponent {
  @Input() evento: Evento;
  @Output() guardarCambios = new EventEmitter<Evento>();
  editable: boolean = false;

  cambiarEditable() {
    if (this.editable) {
      this.guardarCambios.emit(this.evento);
    }

    this.editable = !this.editable;
  }
}
