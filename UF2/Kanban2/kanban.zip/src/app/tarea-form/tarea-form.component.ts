import {Component, EventEmitter, NgModule, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormArray} from "@angular/forms";
import {Tarea} from "../models/tarea-model";

@Component({
  selector: 'app-tarea-form',
  templateUrl: './tarea-form.component.html',
  styleUrls: ['./tarea-form.component.css']
})

export class TareaFormComponent implements OnInit {

  tascaForm!: FormGroup;
  users: number = 0;
  @Output() formularioEnviado = new EventEmitter<Tarea>();

  constructor(private fb: FormBuilder) {
    this.tascaForm = this.fb.group({
      titulo: ['', Validators.required],
      lista: ['', Validators.required],
      fechaFin: [null],
      img: [''],
      usuarios: [0],
    });
  }
  ngOnInit() {
  }

  guardar(): void {
    let usuariosArray: { email: string; img: string; nick: string; alt: string; }[] = [];

    if (this.users === 1) {
      usuariosArray = [{"email": "lponts@ilerna.com", "img": "https://picsum.photos/100/100", "nick": "Juan", "alt": "Usuario"}];
    } else if (this.users === 2) {
      usuariosArray = [
        {"email": "lponts@ilerna.com", "img": "https://picsum.photos/100/100", "nick": "Juan", "alt": "Usuario"},
        {"email": "lponts@ilerna.com", "img": "https://picsum.photos/100/100", "nick": "Juan", "alt": "Usuario"}
      ];
    }

    this.tascaForm.get('usuarios')?.setValue(usuariosArray);
    this.formularioEnviado.emit(this.tascaForm.value);
  }

  addUsers() {
    this.users += 1;
    this.tascaForm.get('usuarios')?.setValue(this.users);
  }

  deleteUsers() {
    this.users -= 1;
    this.tascaForm.get('usuarios')?.setValue(this.users);
  }


}
