import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {UsersService} from "../services/users.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent {

  loginForm!: FormGroup;

  constructor(private fb: FormBuilder, public userService: UsersService) {
    this.loginForm = this.fb.group({
      email: ['', Validators.email],
      password: [''],
    });
  }

  login() {
    this.userService.login(this.loginForm.value).subscribe(data => {
      console.log(data);
    });    
  }
}
