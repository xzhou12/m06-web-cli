import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Tarjeta } from '../models/tarjeta.model';

@Component({
  selector: 'app-tarjeta-nueva',
  templateUrl: './tarjeta-nueva.component.html',
  styleUrls: ['./tarjeta-nueva.component.css']
})
export class TarjetaNuevaComponent {
  tarjetaForm!: FormGroup;

  @Output() formularioEnviado = new EventEmitter<Tarjeta>();
  @Output() cancelar = new EventEmitter<void>();

  constructor(private fb: FormBuilder) {
    this.tarjetaForm = this.fb.group({
      avatar: ['', Validators.required],
      nombre: ['', Validators.required],
      apodo: ['', Validators.required],
      imagen: ['', Validators.required],
      descripcion: ['', Validators.required],
      favorito: [''],
      gusta: [''],
    });
  }


  guardar() {
    this.formularioEnviado.emit(this.tarjetaForm.value);
  }

  cancelarFormulario() {
    this.cancelar.emit();
  }
}
