export interface Usuario {
  email: string;
  nombre: string;
  img?: string;
}
